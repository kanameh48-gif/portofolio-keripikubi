// ==========================================================================
// KERIPIKUBI — INTERACTIVE PORTFOLIO ENGINE (100% PURE VANILLA ES6+ JS)
// ==========================================================================

const MODAL_DATABASE = {
  // Tab 2: Trofi Visual
  'trofi-goblin': {
    tag: 'TROFI UTAMA · RANK SSS',
    title: 'Goblin Slayer Rank SSS',
    story:
      'Dianugerahkan setelah berhasil membasmi 404 bug kosmetik seperti jarak padding 1px yang miring, sambil dengan tenang mengabaikan 1 bug fatal di database produksi karena "belum ada yang komplain".',
    stats: 'Bug Receh Dibasmi: 404 · Server Meledak: 1 · Tingkat Kepanikan: 0%'
  },
  'trofi-pertamax': {
    tag: 'TROFI UTAMA · REKOR KECEPATAN',
    title: 'Raja Pertamax Abadi',
    story:
      'Rekor dunia mengetik "Komentar Pertama!" hanya dalam 0.02 detik sejak notifikasi muncul, jauh sebelum sempat membaca apakah isi postingannya pengumuman penting atau sekadar foto kucing.',
    stats: 'Kecepatan Ketik: 0.02 Detik · Akurasi Konteks: 4% · Ego Boost: +9999'
  },

  // Tab 2: Daftar Pill Pencapaian Sarkas
  'pill-komentar': {
    tag: 'PENCAPAIAN SARKAS · #01',
    title: '🏆 Juara Bertahan Komentar Pertama',
    story:
      'Mempertahankan gelar juara komentar pertama selama 14 musim berturut-turut di grup keluarga dan kolom komentar kreator teknologi berkat jari telunjuk yang selalu siaga di atas layar.',
    stats: 'Total Pertamax: 1.240x · Koneksi Wi-Fi Tetangga: Stabil'
  },
  'pill-goblin': {
    tag: 'PENCAPAIAN SARKAS · #02',
    title: '⚔️ Prestasi Goblin Slayer (Pembasmi Bug Receh)',
    story:
      'Pantang tidur sebelum mengganti warna tombol sebanyak 19 kali, namun langsung menutup laptop saat melihat pesan error lebih dari 3 baris di terminal.',
    stats: 'Warna Tombol Diganti: 19x · Error Terminal Ditutup: 100%'
  },
  'pill-debat': {
    tag: 'PENCAPAIAN SARKAS · #03',
    title: '🚿 Grandmaster Debat Kusir di Kamar Mandi',
    story:
      'Selalu menemukan argumen balasan paling jenius, puitis, dan tak terbantahkan tepat 3 hari setelah perdebatan asli selesai, saat sedang keramas di kamar mandi.',
    stats: 'Kemenangan Imajiner: 100% · Saksi Mata: Botol Sampo'
  },
  'pill-tab': {
    tag: 'PENCAPAIAN SARKAS · #04',
    title: '🗂️ Kolektor 87 Tab Browser Tanpa Dibaca',
    story:
      'Menyimpan puluhan tab dokumentasi, tutorial, dan artikel "nanti pasti dibaca" sejak bulan Februari hingga ukuran ikon tab mengecil menjadi seukuran debu kosmik.',
    stats: 'Tab Terbuka: 87 Tab · RAM Tersisa: Doa & Harapan'
  },
  'pill-pahlawan': {
    tag: 'PENCAPAIAN SARKAS · #05',
    title: '🦉 Pahlawan Kesiangan (Tidur Jam 4 Pagi)',
    story:
      'Mendapatkan lonjakan motivasi luar biasa untuk merombak seluruh struktur hidup dan kode program tepat pukul 02.45 dini hari, lalu bangun jam 11 siang dengan lupa tadi malam nulis apa.',
    stats: 'Jam Produktif: 02:30 - 03:55 WIB · Konsumsi Kopi: 3 Gelas'
  },

  // Tab 3: Bedah Kasus Proyek
  'proyek-kalkulator': {
    tag: 'BEDAH KASUS · SELESAI (KEBETULAN)',
    title: 'Kalkulator Penyesalan Finansial',
    story:
      'Studi kasus berawal dari rasa penasaran kenapa saldo akhir bulan selalu mirip nomor sepatu. Algoritma ini mengonversi riwayat jajan es kopi susu gula aren dan tahu bulat menjadi satuan hektar pulau pribadi di kepulauan tropis.',
    stats: 'Setara Pulau: 1.4 Hektar · Gorengan Terkonsumsi: 4.820 Biji · Solusi: Tetap Jajan'
  },
  'proyek-alasan': {
    tag: 'BEDAH KASUS · EKSPERIMEN BERBAHAYA',
    title: 'Generator Alasan Telat Berbasis Cuaca',
    story:
      'Menggabungkan indikator mendung lokal dengan probabilitas kemacetan imajiner untuk merangkai alasan terlambat yang terdengar sangat ilmiah, dramatis, dan menggugah empati penerima pesan.',
    stats: 'Alasan Tersedia: 320 Variasi · Tingkat Keberhasilan: 88.4% · Risiko Ketahuan: Sedang'
  },
  'proyek-angguk': {
    tag: 'BEDAH KASUS · SELESAI (KEBETULAN)',
    title: 'Simulator Mengangguk Paham',
    story:
      'Dirancang khusus untuk rapat daring ketika klien meminta desain yang "warnanya gelap tapi cerah, font-nya besar tapi hemat ruang, dan selesai sore ini". Memberikan efek anggukan sopan secara otomatis.',
    stats: 'Kecepatan Anggukan: 60 RPM · Ekspresi Wajah: Sangat Meyakinkan'
  },
  'proyek-deadline': {
    tag: 'BEDAH KASUS · WACANA ABADI',
    title: 'Mesin Waktu Deadline',
    story:
      'Eksperimen fisika kuantum tingkat halu untuk menyisipkan "Hari Minggu Bagian Ke-2" sebelum hari Senin tiba. Proyek ini belum pernah selesai karena pengembangnya terus menunda pengerjaan mesin penunda waktu ini.',
    stats: 'Status Proyek: Ditunda Sejak Tahun Lalu · Estimasi Rilis: Kapan-kapan'
  },

  // Tab 4: 3 Pilar Filosofi
  'pilar-rebahan': {
    tag: 'PILAR FILOSOFI 01 · HORIZONTALITAS',
    title: 'Logika Rebahan',
    story:
      'Dalam mazhab Keripikism, gravitasi bekerja paling optimal ketika tubuh berada pada sudut 180 derajat. Ide-ide paling brilian justru muncul saat kita tidak sedang berusaha memikirkannya di depan meja kerja.',
    stats: 'Sudut Optimal: 180° · Efisiensi Energi: +300%'
  },
  'pilar-copypaste': {
    tag: 'PILAR FILOSOFI 02 · EKOLOGI KODE',
    title: 'Etika Copy-Paste',
    story:
      'Menulis ulang fungsi yang sudah pernah kita buat tahun lalu adalah pemborosan energi kinetik jari. Menyalin dan memodifikasi kode lama adalah bentuk pelestarian sejarah digital.',
    stats: 'Jari Terselamatkan: 10 Jari · Jejak Karbon Ketikan: Turun 75%'
  },
  'pilar-ketenangan': {
    tag: 'PILAR FILOSOFI 03 · ATARAXIA UI',
    title: 'Ketenangan Batin',
    story:
      'Ketenangan sejati tercapai saat seorang pengrajin antarmuka ikhlas menerima bahwa animasi yang dikerjakan selama 6 jam kadang dilewati user hanya dalam 0.3 detik.',
    stats: 'Tingkat Keikhlasan: 99.9% · Kedamaian Batin: Maksimal'
  }
};

const ENTRY_DIRECTIONS = ['from-top', 'from-bottom', 'from-left', 'from-right', 'scale-drop'];

document.addEventListener('DOMContentLoaded', () => {
  const htmlEl = document.documentElement;
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const emergencyNavBtn = document.getElementById('emergencyNavBtn');
  const brandHomeLink = document.getElementById('brandHomeLink');
  const tabButtons = document.querySelectorAll('.nav-tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');
  const jumpTabButtons = document.querySelectorAll('[data-jump-tab]');
  const filterButtons = document.querySelectorAll('.filter-pill-btn');
  const projectCards = document.querySelectorAll('.project-card');
  const replayAnimBtn = document.getElementById('replayAnimBtn');

  // Modal Elements
  const modalBackdrop = document.getElementById('detailModalBackdrop');
  const modalCloseBtn = document.getElementById('modalCloseBtn');
  const modalCategoryTag = document.getElementById('modalCategoryTag');
  const modalTitle = document.getElementById('modalTitle');
  const modalStory = document.getElementById('modalStory');
  const modalStats = document.getElementById('modalStats');

  // Toast Element
  const customToast = document.getElementById('customToast');
  let toastTimer = null;

  // =========================================================================
  // 1. THEME TOGGLE (LIGHT / DARK MODE) DENGAN ANIMASI PUTAR IKON SVG
  // =========================================================================
  const savedTheme = localStorage.getItem('keripikubi_theme');
  if (savedTheme === 'dark') {
    htmlEl.classList.add('dark');
  }

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      themeToggleBtn.classList.remove('spin-anim');
      void themeToggleBtn.offsetWidth; // Reflow untuk memicu ulang animasi putar
      themeToggleBtn.classList.add('spin-anim');

      const isDark = htmlEl.classList.toggle('dark');
      localStorage.setItem('keripikubi_theme', isDark ? 'dark' : 'light');
      showToast(
        isDark
          ? 'Mode Gelap aktif! Cocok untuk ngoding jam 3 pagi sambil rebahan.'
          : 'Mode Terang aktif! Silau sedikit tapi bikin melek saat revisi.'
      );
    });
  }

  // =========================================================================
  // 2. MULTI-DIRECTIONAL FLY-IN ENGINE (RESET & TRIGGER ULANG)
  // =========================================================================
  function triggerPanelFlyIn(panelElement, randomizeDirections = false) {
    if (!panelElement) return;
    const entryItems = panelElement.querySelectorAll('[data-entry]');

    entryItems.forEach((el) => {
      el.classList.remove('entry-active');
      if (randomizeDirections && !el.classList.contains('giant-watermark')) {
        const randomDir = ENTRY_DIRECTIONS[Math.floor(Math.random() * 4)];
        el.setAttribute('data-entry', randomDir);
      }
    });

    // Paksa browser reflow agar transisi cubic-bezier pegas berjalan mulus dari awal
    void panelElement.offsetWidth;

    entryItems.forEach((el, index) => {
      const delayMs = Math.min(index * 65, 420);
      el.style.setProperty('--entry-delay', `${delayMs}ms`);
      el.classList.add('entry-active');
    });
  }

  // Jalankan animasi fly-in pertama kali pada tab default (Markas Besar)
  const initialActivePanel = document.querySelector('.tab-panel.active');
  triggerPanelFlyIn(initialActivePanel, false);

  // =========================================================================
  // 3. NAVIGASI 4 TAB INTERAKTIF & TOMBOL LONCAT TAB
  // =========================================================================
  function switchTab(targetTabId, scrollToId = null) {
    tabButtons.forEach((btn) => {
      const isMatch = btn.getAttribute('data-tab-target') === targetTabId;
      btn.classList.toggle('active', isMatch);
      btn.setAttribute('aria-selected', isMatch ? 'true' : 'false');
    });

    let activePanel = null;
    tabPanels.forEach((panel) => {
      const isMatch = panel.id === targetTabId;
      panel.classList.toggle('active', isMatch);
      if (isMatch) {
        activePanel = panel;
      }
    });

    if (activePanel) {
      triggerPanelFlyIn(activePanel, false);
    }

    if (scrollToId) {
      const targetEl = document.getElementById(scrollToId);
      if (targetEl) {
        setTimeout(() => {
          targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 120);
      }
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  tabButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const targetTabId = btn.getAttribute('data-tab-target');
      switchTab(targetTabId);
    });
  });

  jumpTabButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const targetTabId = btn.getAttribute('data-jump-tab');
      switchTab(targetTabId);
    });
  });

  if (brandHomeLink) {
    brandHomeLink.addEventListener('click', (e) => {
      e.preventDefault();
      switchTab('tab-markas');
    });
  }

  // Tombol kapsul "Sinyal Darurat" di kanan navbar -> buka Tab 4 & scroll ke kontak
  if (emergencyNavBtn) {
    emergencyNavBtn.addEventListener('click', () => {
      switchTab('tab-filosofi', 'emergencyContactSection');
      showToast('Menuju Panel Sinyal Darurat! Siapkan alasan terbaik Anda.');
    });
  }

  // =========================================================================
  // 4. FILTER KATEGORI PROYEK DI TAB 3 (FLY-IN ULANG DARI BERBAGAI ARAH)
  // =========================================================================
  filterButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const selectedFilter = btn.getAttribute('data-filter');

      filterButtons.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');

      const directionsCycle = ['from-left', 'from-right', 'from-bottom', 'from-top'];
      let visibleIndex = 0;

      projectCards.forEach((card) => {
        const cardCat = card.getAttribute('data-category');
        const shouldShow = selectedFilter === 'all' || cardCat === selectedFilter;

        card.classList.remove('entry-active');

        if (shouldShow) {
          card.classList.remove('hidden-by-filter');
          const nextDir = directionsCycle[visibleIndex % directionsCycle.length];
          card.setAttribute('data-entry', nextDir);
          visibleIndex++;
        } else {
          card.classList.add('hidden-by-filter');
        }
      });

      const projectsGrid = document.getElementById('projectsGrid');
      if (projectsGrid) {
        void projectsGrid.offsetWidth;
      }

      projectCards.forEach((card, idx) => {
        if (!card.classList.contains('hidden-by-filter')) {
          card.style.setProperty('--entry-delay', `${idx * 70}ms`);
          card.classList.add('entry-active');
        }
      });
    });
  });

  // =========================================================================
  // 5. INTERACTIVE DETAIL MODAL (TAB 2 PENCAPAIAN, TAB 3 BEDAH KASUS, TAB 4 PILAR)
  // =========================================================================
  function openDetailModal(modalKey) {
    const data = MODAL_DATABASE[modalKey];
    if (!data || !modalBackdrop) return;

    modalCategoryTag.textContent = data.tag;
    modalTitle.textContent = data.title;
    modalStory.textContent = data.story;
    modalStats.textContent = data.stats;

    modalBackdrop.classList.add('open');
  }

  function closeDetailModal() {
    if (!modalBackdrop) return;
    modalBackdrop.classList.remove('open');
  }

  const modalTriggers = document.querySelectorAll('[data-modal-id]');
  modalTriggers.forEach((trigger) => {
    trigger.addEventListener('click', () => {
      if (trigger.classList.contains('pillar-card')) {
        document.querySelectorAll('.pillar-card').forEach((c) => c.classList.remove('active'));
        trigger.classList.add('active');
      }
      const modalKey = trigger.getAttribute('data-modal-id');
      openDetailModal(modalKey);
    });
  });

  if (modalCloseBtn) {
    modalCloseBtn.addEventListener('click', closeDetailModal);
  }

  if (modalBackdrop) {
    modalBackdrop.addEventListener('click', (e) => {
      if (e.target === modalBackdrop) {
        closeDetailModal();
      }
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalBackdrop && modalBackdrop.classList.contains('open')) {
      closeDetailModal();
    }
  });

  // =========================================================================
  // 6. PANEL SINYAL DARURAT & KONTAK + CUSTOM TOAST NOTIFICATION
  // =========================================================================
  function showToast(message) {
    if (!customToast) return;
    customToast.textContent = message;
    customToast.classList.add('show');

    if (toastTimer) {
      clearTimeout(toastTimer);
    }
    toastTimer = setTimeout(() => {
      customToast.classList.remove('show');
    }, 3400);
  }

  const contactButtons = document.querySelectorAll('[data-contact-action]');
  contactButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const actionType = btn.getAttribute('data-contact-action');

      if (actionType === 'email') {
        const emergencyEmail = 'keripikubi473@gmail.com';
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(emergencyEmail).catch(() => {});
        }
        showToast('Sinyal darurat (keripikubi473@gmail.com) disalin! Balasan dikirim setelah selesai ngopi.');
      } else if (actionType === 'tiktok') {
        showToast('Frekuensi TikTok @keripikubi terkunci! Jangan lupa kasih komentar pertama.');
      } else if (actionType === 'github') {
        showToast('Repositori GitHub Keripikubi: 90% wacana eksperimen, 10% kode ajaib yang jalan sendiri.');
      } else if (actionType === 'instagram') {
        showToast('Sinyal Instagram Keripikubi terpancar! Sedang rebahan estetis hari ini.');
      }
    });
  });

  // =========================================================================
  // 7. REPLAY ANIMATION TRIGGER (🎲 ACAK ULANG ANIMASI)
  // =========================================================================
  if (replayAnimBtn) {
    replayAnimBtn.addEventListener('click', () => {
      const currentActivePanel = document.querySelector('.tab-panel.active');
      triggerPanelFlyIn(currentActivePanel, true);
      showToast('🎲 Efek multi-directional fly-in diacak ulang dengan pegas penuh!');
    });
  }
});
